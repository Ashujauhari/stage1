package exception;

import java.util.Scanner;

public class ExceptionHandling
{
    public static void main(String[] args)
   
    {
    	int ch=0;
    	while(ch!=-1)
    	{
    	System.out.println("Enter Choice");
    	Scanner sc= new Scanner(System.in);
    	ch=sc.nextInt();
    	switch(ch)
    	{
		case 1:
			{System.out.println("This statement will be executed"); 
	        try
	        {    Integer I = new Integer("abc");  //This statement throws NumberFormatException
	        }
	       catch (Exception e)
	        { System.out.println("exception caught"); }
	 
	        System.out.println("Now, This statement will also be executed");
		    }
			break;
    	
    	
    	case 2:
    	{
    		System.out.println("This statement will be executed"); 
    		 
            try
            {
                int i = 1000/0;    //This statement throws ArithmaticException : / by zero
            }
            catch (Exception e)
            {
                System.out.println("Exception Caught");
            }
     
            System.out.println("Now, This statement will also be executed");
    		break;
    	}
    	
    
    	
    	}	
    		
    }}}
    
