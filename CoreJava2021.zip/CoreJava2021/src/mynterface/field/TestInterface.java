package mynterface.field;

//interface declaration
interface TestInterface{
 public static int value = 100;       //interface field
 public void display();
}