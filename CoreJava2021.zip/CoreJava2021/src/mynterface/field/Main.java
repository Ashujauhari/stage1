package mynterface.field;
//Interface implementation
class TestClass implements TestInterface{
			 public static int value = 5000;      //class fields
			 public void display() {
			    System.out.println("TestClass::display () method");
			 }
			 public void show() {
			    System.out.println("TestClass::show () method");
			 }
}
public class Main{
 public static void main(String args[]) {
    TestClass testObj = new TestClass();
    //print interface and class field values.
    System.out.println("Value of the interface variable (value): "+TestInterface.value);
    System.out.println("Value of the class variable (value): "+testObj.value);
 }
}