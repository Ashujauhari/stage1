package com.stringpack;

public class StringCreation {
 public static void main(String args[]){  
	//creating a string by java string literal 
		String str = "Java"; 
		char wish[]={'h','e','l','l','o'}; 
		//converting char array wish[] to string str2
		String str2 = new String(wish); 
			
		//creating another java string str3 by using new keyword 
		String str3 = new String("Java String Example"); 
			
		//Displaying all the three strings
		System.out.println(str);  
		System.out.println(str2);  
		System.out.println(str3);  
}
}