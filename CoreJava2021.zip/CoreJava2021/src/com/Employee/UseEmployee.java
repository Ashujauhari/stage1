package com.Employee;

public class UseEmployee {

	public static void main(String[] args) {
		Employee empObj = new Employee();
		empObj.setEno(100);
		System.out.println(empObj.getEno());
		
		int[] a= {1,2,3,4};
		
	}

}
