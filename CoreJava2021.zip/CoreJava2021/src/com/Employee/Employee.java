package com.Employee;

public class Employee {
	
	private int Eno;
	private String Ename;
	//parametized
	public Employee(int eno, String ename) {
		super();
		Eno = eno;
		Ename = ename;
	}
	
	//Default Constructor
	public Employee() {
		
	}
 //To retrieve the object Data
	public int getEno() {
		return Eno;
	}
	public String getEname() {
		return Ename;
	}

	//Set the Data in object
	public void setEname(String ename) {
		Ename = ename;
	}
	
	public void setEno(int eno) {
		Eno = eno;
	}

	
	
	
	
	
	
	
	

}
