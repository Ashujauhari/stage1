package myinterface.method;

public interface Polygon_Shape {
	void calculateArea(int length, int breadth);
}
