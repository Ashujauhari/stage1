package collection;

import java.util.Iterator;
import java.util.LinkedList;

public class TestLinkedList {

	public static void main(String[] args) {
		LinkedList<String> llist = new LinkedList();

		  llist.add("Hello");
		  llist.add("Java");
		  llist.add("Like");
		  llist.add("Java");
		  llist.add("Application");
		  
		  
		  // print the size of the linked list

		  System.out.println("linked List size:" + llist.size());
		  
		  System.out.println("Linked List :" + llist);

		  // set Iterator at specified index

		  Iterator<String> itr = llist.listIterator(3);

		  while (itr.hasNext()) {

		  System.out.println(itr.next());
		  
		  
		// create an array and copy the list to it

		  Object[] array = llist.toArray();

		 // print the array

		  for (int i = 0; i < llist.size(); i++) {

		  System.out.println("Array:" + array[i]);

		  }

		  }	

	}

}
