package system;

public class TestSystem {
public static void main(String args[])
{	 
	System.out.println("Current time in nanoseconds = "+System.nanoTime());
	  String a="cognizant"+System.lineSeparator()+"Technology"; 

}
}
