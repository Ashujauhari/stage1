package myabstract.method;

class PerEmpWor
{
public static void main(String args[])
{
Person p1; // abstract class

Employee e1=new Employee();
e1.accept(201,"Alex","Pune"); //parameter as Emp_no,Emp_Name,address)

Worker m1=new Worker();
m1.accept("Raj",8); //parameter as(Name,WorkingHours)

System.out.println("\n———–Employee———–");
p1=e1;
p1.display();

System.out.println("\n---------Worker---------");
p1=m1; p1.display();
}}