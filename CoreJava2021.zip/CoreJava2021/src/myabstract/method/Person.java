package myabstract.method;

abstract class Person
{
void accept() { }
abstract void display();

}