package myabstract.method;

class Worker extends Person
{
int wh;
String name;
Worker()
{
wh=0;
name=null;
}
void accept(String n,int h)
{
wh=h;
name=n;
}
void display()
{
System.out.println(" Name = "+name);
System.out.println(" Workng hour = "+wh);

}
}

