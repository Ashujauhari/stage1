package myabstract.method;

class Employee extends Person
{
int Emp_no;
String Emp_name,add;

Employee()
{
	Emp_no=0;
	Emp_name=null;
	add=null;
}
void accept(int no,String n,String a)
{
Emp_no=no;
Emp_name=n;
add=a;
}
void display()
{
	System.out.println("Emp_no="+Emp_no);
	System.out.println("Emp_name="+Emp_name);
	System.out.println("Address="+add);
	
}
}