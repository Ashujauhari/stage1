package poly.methodoverriden;

public class poly {

}
