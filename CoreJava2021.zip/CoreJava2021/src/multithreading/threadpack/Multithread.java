package multithreading.threadpack;

// Main Class 
public class Multithread 
{ 
    public static void main(String[] args) 
    { 
        int n = 8; // Number of threads 
        for (int i=0; i<n; i++) 
        {      MultithreadingDemoThread object = new MultithreadingDemoThread(); 
            object.start(); 
        } 
    } 
} 