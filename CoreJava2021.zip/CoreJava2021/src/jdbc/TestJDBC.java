package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestJDBC {

	public static void main(String[] args) {
		JavaUtil javaUtil = new JavaUtil(); 
		javaUtil.insertUser(7, "Alex", "John", "alex@gmail.com");
		//javaUtil.displayRecord();
	//avaUtil.deleteRecord(100l);
		javaUtil.updateRecord(5l);
	}
}
