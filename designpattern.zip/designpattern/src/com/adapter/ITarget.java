package com.adapter;

public interface ITarget
{
 public void processCompanySalary(String[][] employeeInfo);
}
