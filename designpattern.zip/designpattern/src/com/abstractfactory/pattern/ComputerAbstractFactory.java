package com.abstractfactory.pattern;


public interface ComputerAbstractFactory {

	public Computer createComputer();

}